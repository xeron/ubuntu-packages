#ifndef MOUNT_DEVNAME_H
#define MOUNT_DEVNAME_H

extern const char *spec_to_devname(const char *spec);

#endif
