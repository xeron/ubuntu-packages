#ifndef WHOLEDISK_H
#define WHOLEDISK_H

extern int is_whole_disk(const char *name);
extern int is_whole_disk_fd(int fd, const char *name);

#endif /* WHOLEDISK_H */

