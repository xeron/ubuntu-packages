#define NEW gsd_media_keys_manager_new
#define START gsd_media_keys_manager_start
#define STOP gsd_media_keys_manager_stop
#define MANAGER GsdMediaKeysManager
#include "gsd-media-keys-manager.h"

#include "test-plugin.h"
