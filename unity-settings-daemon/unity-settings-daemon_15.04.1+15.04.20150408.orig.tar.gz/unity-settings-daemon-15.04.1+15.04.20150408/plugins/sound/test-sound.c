#define NEW gsd_sound_manager_new
#define START gsd_sound_manager_start
#define STOP gsd_sound_manager_stop
#define MANAGER GsdSoundManager
#include "gsd-sound-manager.h"

#include "test-plugin.h"
