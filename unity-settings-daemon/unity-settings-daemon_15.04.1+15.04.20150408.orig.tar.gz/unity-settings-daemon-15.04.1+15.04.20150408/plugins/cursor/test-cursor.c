#define NEW gsd_cursor_manager_new
#define START gsd_cursor_manager_start
#define STOP gsd_cursor_manager_stop
#define MANAGER GsdCursorManager
#include "gsd-cursor-manager.h"

#include "test-plugin.h"
