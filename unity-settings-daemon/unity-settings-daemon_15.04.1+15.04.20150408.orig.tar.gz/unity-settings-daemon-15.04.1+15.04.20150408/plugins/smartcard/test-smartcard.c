#define NEW gsd_smartcard_manager_new_default
#define START gsd_smartcard_manager_start
#define STOP gsd_smartcard_manager_stop
#define MANAGER GsdSmartcardManager
#include "gsd-smartcard-manager.h"

#include "test-plugin.h"
