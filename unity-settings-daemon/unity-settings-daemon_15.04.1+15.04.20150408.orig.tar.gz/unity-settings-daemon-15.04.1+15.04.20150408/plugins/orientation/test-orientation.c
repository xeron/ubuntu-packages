#define NEW gsd_orientation_manager_new
#define START gsd_orientation_manager_start
#define STOP gsd_orientation_manager_stop
#define MANAGER GsdOrientationManager
#include "gsd-orientation-manager.h"

#include "test-plugin.h"
