#define NEW gsd_remote_display_manager_new
#define START gsd_remote_display_manager_start
#define STOP gsd_remote_display_manager_stop
#define MANAGER GsdRemoteDisplayManager
#include "gsd-remote-display-manager.h"

#include "test-plugin.h"
