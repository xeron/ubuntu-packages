#define NEW gnome_xsettings_manager_new
#define START gnome_xsettings_manager_start
#define STOP gnome_xsettings_manager_stop
#define MANAGER GnomeXSettingsManager
#include "gsd-xsettings-manager.h"

#include "test-plugin.h"
