#define NEW gsd_mouse_manager_new
#define START gsd_mouse_manager_start
#define STOP gsd_mouse_manager_stop
#define MANAGER GsdMouseManager
#include "gsd-mouse-manager.h"

#include "test-plugin.h"
