#define NEW gsd_xrandr_manager_new
#define START gsd_xrandr_manager_start
#define STOP gsd_xrandr_manager_stop
#define MANAGER GsdXrandrManager
#include "gsd-xrandr-manager.h"

#include "test-plugin.h"
