#define NEW gsd_background_manager_new
#define START gsd_background_manager_start
#define STOP gsd_background_manager_stop
#define MANAGER GsdBackgroundManager
#include "gsd-background-manager.h"

#include "test-plugin.h"
