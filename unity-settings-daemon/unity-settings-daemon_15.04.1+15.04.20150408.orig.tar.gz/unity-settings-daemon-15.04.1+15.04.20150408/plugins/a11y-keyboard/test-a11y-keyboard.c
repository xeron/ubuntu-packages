#define NEW gsd_a11y_keyboard_manager_new
#define START gsd_a11y_keyboard_manager_start
#define STOP gsd_a11y_keyboard_manager_stop
#define MANAGER GsdA11yKeyboardManager
#include "gsd-a11y-keyboard-manager.h"

#include "test-plugin.h"
