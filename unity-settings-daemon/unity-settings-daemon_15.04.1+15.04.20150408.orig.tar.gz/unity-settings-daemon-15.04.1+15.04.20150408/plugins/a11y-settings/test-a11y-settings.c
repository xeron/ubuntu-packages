#define NEW gsd_a11y_settings_manager_new
#define START gsd_a11y_settings_manager_start
#define STOP gsd_a11y_settings_manager_stop
#define MANAGER GsdA11ySettingsManager
#include "gsd-a11y-settings-manager.h"

#include "test-plugin.h"
