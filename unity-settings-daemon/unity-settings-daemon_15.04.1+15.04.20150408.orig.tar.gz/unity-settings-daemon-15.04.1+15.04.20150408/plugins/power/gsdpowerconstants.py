
# File auto-generated from script http://git.gnome.org/browse/gnome-settings-daemon/tree/plugins/power/gsd-power-constants-update.pl

# Modified by the GTK+ Team and others 1997-2012.  See the AUTHORS
# file for a list of people on the GTK+ Team.  See the ChangeLog
# files for a list of changes.  These files are distributed with
# GTK+ at ftp://ftp.gtk.org/pub/gtk/.

SCREENSAVER_TIMEOUT_BLANK = 15;
IDLE_DIM_BLANK_DISABLED_MIN = 60;
IDLE_DELAY_TO_IDLE_DIM_MULTIPLIER = 4.0/5.0;
MINIMUM_IDLE_DIM_DELAY = 10;
POWER_UP_TIME_ON_AC = 15;
GSD_MOCK_DEFAULT_BRIGHTNESS = 50;
GSD_MOCK_MAX_BRIGHTNESS = 100;
