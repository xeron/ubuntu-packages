#define NEW gsd_power_manager_new
#define START gsd_power_manager_start
#define STOP gsd_power_manager_stop
#define MANAGER GsdPowerManager
#include "gsd-power-manager.h"

#include "test-plugin.h"
